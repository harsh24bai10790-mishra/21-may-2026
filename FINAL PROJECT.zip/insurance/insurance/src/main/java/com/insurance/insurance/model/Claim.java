package com.insurance.insurance.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="claims")
public class Claim {

    @Id
    private String id;

    private String claimDate;
    private double amount;
    private String reason;
    private String status;
    private String policyId;

    public Claim() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getClaimDate() { return claimDate; }
    public void setClaimDate(String claimDate) {
        this.claimDate = claimDate;
    }

    public double getAmount() { return amount; }
    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getReason() { return reason; }
    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() { return status; }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getPolicyId() { return policyId; }
    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }
}