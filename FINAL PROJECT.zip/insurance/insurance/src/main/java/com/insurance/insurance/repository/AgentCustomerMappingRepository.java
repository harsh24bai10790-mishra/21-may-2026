package com.insurance.insurance.repository;

import com.insurance.insurance.model.AgentCustomerMapping;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AgentCustomerMappingRepository
        extends MongoRepository<AgentCustomerMapping, String> {
}