package com.insurance.insurance.repository;

import com.insurance.insurance.model.PremiumPayment;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PremiumPaymentRepository
        extends MongoRepository<PremiumPayment, String> {
}