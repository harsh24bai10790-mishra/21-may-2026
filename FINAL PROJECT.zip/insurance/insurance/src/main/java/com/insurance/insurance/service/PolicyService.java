package com.insurance.insurance.service;

import com.insurance.insurance.model.Policy;
import com.insurance.insurance.repository.PolicyRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PolicyService {

    private final PolicyRepository repository;

    public PolicyService(PolicyRepository repository) {
        this.repository = repository;
    }

    public List<Policy> getAll() {
        return repository.findAll();
    }

    public Policy getById(String id) {
        return repository.findById(id).orElse(null);
    }

    public Policy save(Policy policy) {
        return repository.save(policy);
    }

    public Policy update(String id, Policy policy) {
        policy.setId(id);
        return repository.save(policy);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }

    public Policy renewPolicy(String id) {

        Policy policy = repository.findById(id).orElse(null);

        if (policy != null) {
            policy.setStatus("Renewed");
            return repository.save(policy);
        }

        return null;
    }
}