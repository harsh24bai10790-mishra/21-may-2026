package com.insurance.insurance.service;

import com.insurance.insurance.model.Agent;
import com.insurance.insurance.repository.AgentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AgentService {

    private final AgentRepository repository;

    public AgentService(AgentRepository repository) {
        this.repository = repository;
    }

    public List<Agent> getAll() {
        return repository.findAll();
    }

    public Agent getById(String id) {
        return repository.findById(id).orElse(null);
    }

    public Agent save(Agent agent) {
        return repository.save(agent);
    }

    public Agent update(String id, Agent agent) {
        agent.setId(id);
        return repository.save(agent);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }
}