package com.insurance.insurance.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="policies")
public class Policy {

    @Id
    private String id;

    private String policyNumber;
    private String type;
    private double premiumAmount;
    private String startDate;
    private String endDate;
    private String status;

    private String customerId;
    private String agentId;

    private Nominee nominee;

    public Policy() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPolicyNumber() { return policyNumber; }
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public double getPremiumAmount() { return premiumAmount; }
    public void setPremiumAmount(double premiumAmount) {
        this.premiumAmount = premiumAmount;
    }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStatus() { return status; }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getAgentId() { return agentId; }
    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public Nominee getNominee() { return nominee; }
    public void setNominee(Nominee nominee) {
        this.nominee = nominee;
    }
}