package com.insurance.insurance.controller;

import com.insurance.insurance.model.Agent;
import com.insurance.insurance.service.AgentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/agents")
public class AgentController {

    private final AgentService service;

    public AgentController(AgentService service) {
        this.service = service;
    }

    @GetMapping
    public List<Agent> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Agent getById(@PathVariable String id) {
        return service.getById(id);
    }

    @PostMapping
    public Agent create(@RequestBody Agent agent) {
        return service.save(agent);
    }

    @PutMapping("/{id}")
    public Agent update(
            @PathVariable String id,
            @RequestBody Agent agent) {

        return service.update(id, agent);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable String id) {
        service.delete(id);
        return "Agent Deleted Successfully";
    }
}