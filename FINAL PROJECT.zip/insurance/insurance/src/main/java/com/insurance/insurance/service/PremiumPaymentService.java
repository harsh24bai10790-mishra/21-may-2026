package com.insurance.insurance.service;

import com.insurance.insurance.model.PremiumPayment;
import com.insurance.insurance.repository.PremiumPaymentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PremiumPaymentService {

    private final PremiumPaymentRepository repository;

    public PremiumPaymentService(
            PremiumPaymentRepository repository) {

        this.repository = repository;
    }

    public List<PremiumPayment> getAll() {
        return repository.findAll();
    }

    public PremiumPayment getById(String id) {
        return repository.findById(id).orElse(null);
    }

    public PremiumPayment save(PremiumPayment payment) {
        return repository.save(payment);
    }

    public PremiumPayment update(
            String id,
            PremiumPayment payment) {

        payment.setId(id);
        return repository.save(payment);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }
}