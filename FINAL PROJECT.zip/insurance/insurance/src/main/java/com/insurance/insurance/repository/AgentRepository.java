package com.insurance.insurance.repository;

import com.insurance.insurance.model.Agent;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AgentRepository
        extends MongoRepository<Agent, String> {
}