package com.insurance.insurance.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="premium_payments")
public class PremiumPayment {

    @Id
    private String id;

    private String paymentDate;
    private double amount;
    private String mode;
    private String policyId;

    public PremiumPayment() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPaymentDate() { return paymentDate; }
    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public double getAmount() { return amount; }
    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getMode() { return mode; }
    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getPolicyId() { return policyId; }
    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }
}