package com.insurance.insurance.controller;

import com.insurance.insurance.model.Policy;
import com.insurance.insurance.service.PolicyService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/policies")
public class PolicyController {

    private final PolicyService service;

    public PolicyController(PolicyService service) {
        this.service = service;
    }

    @GetMapping
    public List<Policy> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Policy getById(@PathVariable String id) {
        return service.getById(id);
    }

    @PostMapping
    public Policy create(@RequestBody Policy policy) {
        return service.save(policy);
    }

    @PutMapping("/{id}")
    public Policy update(
            @PathVariable String id,
            @RequestBody Policy policy) {

        return service.update(id, policy);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable String id) {
        service.delete(id);
        return "Policy Deleted Successfully";
    }

    @PutMapping("/{id}/renew")
    public Policy renewPolicy(@PathVariable String id) {
        return service.renewPolicy(id);
    }
}