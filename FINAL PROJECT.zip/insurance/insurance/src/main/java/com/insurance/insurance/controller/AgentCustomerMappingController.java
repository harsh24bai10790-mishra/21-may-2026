package com.insurance.insurance.controller;

import com.insurance.insurance.model.AgentCustomerMapping;
import com.insurance.insurance.service.AgentCustomerMappingService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/agent-customer")
public class AgentCustomerMappingController {

    private final AgentCustomerMappingService service;

    public AgentCustomerMappingController(
            AgentCustomerMappingService service) {

        this.service = service;
    }

    @GetMapping
    public List<AgentCustomerMapping> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public AgentCustomerMapping getById(
            @PathVariable String id) {

        return service.getById(id);
    }

    @PostMapping
    public AgentCustomerMapping create(
            @RequestBody AgentCustomerMapping mapping) {

        return service.save(mapping);
    }

    @PutMapping("/{id}")
    public AgentCustomerMapping update(
            @PathVariable String id,
            @RequestBody AgentCustomerMapping mapping) {

        return service.update(id, mapping);
    }

    @DeleteMapping("/{id}")
    public String delete(
            @PathVariable String id) {

        service.delete(id);
        return "Mapping Deleted Successfully";
    }
}