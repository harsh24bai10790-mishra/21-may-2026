package com.insurance.insurance.controller;

import com.insurance.insurance.model.PremiumPayment;
import com.insurance.insurance.service.PremiumPaymentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/premium-payments")
public class PremiumPaymentController {

    private final PremiumPaymentService service;

    public PremiumPaymentController(
            PremiumPaymentService service) {

        this.service = service;
    }

    @GetMapping
    public List<PremiumPayment> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public PremiumPayment getById(
            @PathVariable String id) {

        return service.getById(id);
    }

    @PostMapping
    public PremiumPayment create(
            @RequestBody PremiumPayment payment) {

        return service.save(payment);
    }

    @PutMapping("/{id}")
    public PremiumPayment update(
            @PathVariable String id,
            @RequestBody PremiumPayment payment) {

        return service.update(id, payment);
    }

    @DeleteMapping("/{id}")
    public String delete(
            @PathVariable String id) {

        service.delete(id);
        return "Payment Deleted Successfully";
    }
}