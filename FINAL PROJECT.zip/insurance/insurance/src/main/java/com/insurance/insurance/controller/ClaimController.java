package com.insurance.insurance.controller;

import com.insurance.insurance.model.Claim;
import com.insurance.insurance.service.ClaimService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/claims")
public class ClaimController {

    private final ClaimService service;

    public ClaimController(ClaimService service) {
        this.service = service;
    }

    @GetMapping
    public List<Claim> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Claim getById(@PathVariable String id) {
        return service.getById(id);
    }

    @PostMapping
    public Claim create(@RequestBody Claim claim) {
        return service.save(claim);
    }

    @PutMapping("/{id}")
    public Claim update(
            @PathVariable String id,
            @RequestBody Claim claim) {

        return service.update(id, claim);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable String id) {
        service.delete(id);
        return "Claim Deleted Successfully";
    }

    @PutMapping("/{id}/approve")
    public Claim approveClaim(@PathVariable String id) {
        return service.approveClaim(id);
    }
}