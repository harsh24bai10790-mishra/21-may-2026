package com.insurance.insurance.service;

import com.insurance.insurance.model.Claim;
import com.insurance.insurance.repository.ClaimRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClaimService {

    private final ClaimRepository repository;

    public ClaimService(ClaimRepository repository) {
        this.repository = repository;
    }

    public List<Claim> getAll() {
        return repository.findAll();
    }

    public Claim getById(String id) {
        return repository.findById(id).orElse(null);
    }

    public Claim save(Claim claim) {
        return repository.save(claim);
    }

    public Claim update(String id, Claim claim) {
        claim.setId(id);
        return repository.save(claim);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }

    public Claim approveClaim(String id) {
        Claim claim = repository.findById(id).orElse(null);

        if (claim != null) {
            claim.setStatus("Approved");
            return repository.save(claim);
        }

        return null;
    }
}