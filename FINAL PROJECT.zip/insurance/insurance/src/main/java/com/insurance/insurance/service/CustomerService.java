package com.insurance.insurance.service;

import com.insurance.insurance.model.Customer;
import com.insurance.insurance.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    private final CustomerRepository repository;

    public CustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    public List<Customer> getAll() {
        return repository.findAll();
    }

    public Customer getById(String id) {
        return repository.findById(id).orElse(null);
    }

    public Customer save(Customer customer) {
        return repository.save(customer);
    }

    public Customer update(String id, Customer customer) {
        customer.setId(id);
        return repository.save(customer);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }
}