package com.insurance.insurance.repository;

import com.insurance.insurance.model.Claim;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ClaimRepository
        extends MongoRepository<Claim, String> {
}