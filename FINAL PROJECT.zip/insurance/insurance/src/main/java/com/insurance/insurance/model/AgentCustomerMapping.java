package com.insurance.insurance.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="agent_customer_mapping")
public class AgentCustomerMapping {

    @Id
    private String id;

    private String agentId;
    private String customerId;

    public AgentCustomerMapping() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getAgentId() { return agentId; }
    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
}