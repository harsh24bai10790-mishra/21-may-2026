package com.insurance.insurance.repository;

import com.insurance.insurance.model.Policy;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PolicyRepository
        extends MongoRepository<Policy, String> {
}