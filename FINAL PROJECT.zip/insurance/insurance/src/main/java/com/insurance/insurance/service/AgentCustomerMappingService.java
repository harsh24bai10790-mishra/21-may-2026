package com.insurance.insurance.service;

import com.insurance.insurance.model.AgentCustomerMapping;
import com.insurance.insurance.repository.AgentCustomerMappingRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AgentCustomerMappingService {

    private final AgentCustomerMappingRepository repository;

    public AgentCustomerMappingService(
            AgentCustomerMappingRepository repository) {

        this.repository = repository;
    }

    public List<AgentCustomerMapping> getAll() {
        return repository.findAll();
    }

    public AgentCustomerMapping getById(String id) {
        return repository.findById(id).orElse(null);
    }

    public AgentCustomerMapping save(
            AgentCustomerMapping mapping) {

        return repository.save(mapping);
    }

    public AgentCustomerMapping update(
            String id,
            AgentCustomerMapping mapping) {

        mapping.setId(id);
        return repository.save(mapping);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }
}