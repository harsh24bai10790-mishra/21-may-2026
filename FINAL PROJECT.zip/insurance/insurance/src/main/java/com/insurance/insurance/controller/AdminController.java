package com.insurance.insurance.controller;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final MongoTemplate mongoTemplate;

    public AdminController(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    @DeleteMapping("/drop/{collectionName}")
    public String dropCollection(
            @PathVariable String collectionName) {

        mongoTemplate.dropCollection(collectionName);

        return collectionName + " collection dropped successfully";
    }
}